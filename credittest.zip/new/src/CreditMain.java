import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class CreditMain {

	public static void main(String[] args) throws CreditException {
		final String filePath="C:\\Users\\Ronin\\Desktop\\CreditCard\\CreditCard\\cardInputFile.txt";
		CreditMain creditCard=new CreditMain();
		CreditMain.process(filePath);
	}

	public static Map<String, Map<String, CreditVo>> process(String filePath) throws CreditException {
		
		List<String []> inputDataList= readInputFile(filePath);
		Map<String,CreditVo> voMap=valdiateInput(inputDataList);
		
		
		return null;
		
	}

	private static Map<String, CreditVo> valdiateInput(List<String[]> inputDataList) throws CreditException{
		
		
		return null;
	}

	private static List<String[]> readInputFile(String filePath) throws CreditException {
		
		String[] inputData= new String [20];
		ArrayList<String[]> dataList=new ArrayList<String[]>();
		
		try {
			
		BufferedReader readInput=new BufferedReader(new FileReader(filePath));
		String singleLinefromInput=null;
		String[] wordsInSingleLine= new String[30];
		
		while((singleLinefromInput=readInput.readLine())!=null) {
			
			if(singleLinefromInput!=null && singleLinefromInput.length()>0) {
				wordsInSingleLine=singleLinefromInput.split("\\|");
								
				dataList.add(wordsInSingleLine);
			}
			}
		/*for(String[] data: dataList) {
			for(int i=0;i<data.length;i++) {
				System.out.println(data[i]);
			}
		}*/
		}catch (FileNotFoundException errorMessage) {
			errorMessage.printStackTrace();
				throw new CreditException("Input File not found", errorMessage);
			}
		catch(IOException errorMessage) {
			errorMessage.printStackTrace();
			throw new CreditException("Input Output exception");
			
		}
		
			
		
		
		return dataList;
	}
}



