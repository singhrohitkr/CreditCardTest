

import java.util.*;

public class CreditVo {
	
	private String cardNo;
	private String cardName;
	private String dueAmount;
	private String dueDate;
	private String billDate;
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getDueAmount() {
		return dueAmount;
	}
	public void setDueAmount(String inputFileData) {
		this.dueAmount = inputFileData;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String inputFileData) {
		this.dueDate = inputFileData;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	
	
	

}
