

import java.text.*;
import java.util.*;

class PolicyHolderVO {
	private String policyCode;
	private String pan;
	private Date policyStartDate;
	private int period;
	private float accumulatedPremiumAmount;
	private float requestedLoanAmount;
	private Date policyEndDate;
	private float netPremiumAmount;

	/**
	 * @return the policyCode
	 */
	public String getPolicyCode() {
		return policyCode;
	}

	/**
	 * @param policyCode the policyCode to set
	 */
	public void setPolicyCode(String policyCode) {
		this.policyCode = policyCode;
	}

	/**
	 * @return the pan
	 */
	public String getPan() {
		return pan;
	}

	/**
	 * @param pan the pan to set
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}

	/**
	 * @return the policyStartDate
	 */
	public Date getPolicyStartDate() {
		return policyStartDate;
	}

	/**
	 * @param policyStartDate the policyStartDate to set
	 */
	public void setPolicyStartDate(Date policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	/**
	 * @return the period
	 */
	public int getPeriod() {
		return period;
	}

	/**
	 * @param period the period to set
	 */
	public void setPeriod(int period) {
		this.period = period;
	}

	/**
	 * @return the accumulatedPremiumAmount
	 */
	public float getAccumulatedPremiumAmount() {
		return accumulatedPremiumAmount;
	}

	/**
	 * @param accumulatedPremiumAmount the accumulatedPremiumAmount to set
	 */
	public void setAccumulatedPremiumAmount(float accumulatedPremiumAmount) {
		this.accumulatedPremiumAmount = accumulatedPremiumAmount;
	}

	/**
	 * @return the requestedLoanAmount
	 */
	public float getRequestedLoanAmount() {
		return requestedLoanAmount;
	}

	/**
	 * @param requestedLoanAmount the requestedLoanAmount to set
	 */
	public void setRequestedLoanAmount(float requestedLoanAmount) {
		this.requestedLoanAmount = requestedLoanAmount;
	}

	/**
	 * @return the policyEndDate
	 */
	public Date getPolicyEndDate() {
		return policyEndDate;
	}

	/**
	 * @param policyEndDate the policyEndDate to set
	 */
	public void setPolicyEndDate(Date policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	/**
	 * @return the netPremiumAmount
	 */
	public float getNetPremiumAmount() {
		return netPremiumAmount;
	}

	/**
	 * @param netPremiumAmount the netPremiumAmount to set
	 */
	public void setNetPremiumAmount(float netPremiumAmount) {
		this.netPremiumAmount = netPremiumAmount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PolicyHolderVO [policyCode=");
		builder.append(policyCode);
		builder.append(", pan=");
		builder.append(pan);
		builder.append(", policyStartDate=");
		builder.append(policyStartDate);
		builder.append(", period=");
		builder.append(period);
		builder.append(", accumulatedPremiumAmount=");
		builder.append(accumulatedPremiumAmount);
		builder.append(", requestedLoanAmount=");
		builder.append(requestedLoanAmount);
		builder.append(", policyEndDate=");
		builder.append(policyEndDate);
		builder.append(", netPremiumAmount=");
		builder.append(netPremiumAmount);
		builder.append("]");
		return builder.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object object) {
		boolean isEqual = false;
		PolicyHolderVO other = (PolicyHolderVO) object;
		System.out.println(this.getPolicyEndDate());
		System.out.println(other.getPolicyEndDate());
		if ((this.getPolicyCode().equals(other.getPolicyCode()))
				&& (this.getPolicyStartDate()
						.equals(other.getPolicyStartDate()))
				&& (this.getAccumulatedPremiumAmount() == other
						.getAccumulatedPremiumAmount())) {
			isEqual = true;
		}
		return isEqual;
	}

}