

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class must be used to write the solution for the given requirement. No
 * additional classes must be created.  
 * 
 */
public class TrustLoanSanctioner {

	/**
	 * @param args
	 * @throws TrustLoanException 
	 */
	public static void main(String[] args) throws TrustLoanException {
		// Change this to the absolute path where you have placed the input feed
		String filePath = "H:\\Girish\\trustLoanSanc.txt";
		//String filePath = "input.txt";
		TrustLoanSanctioner tsm = new TrustLoanSanctioner();
	Map<Integer, Map<String, List<PolicyHolderVO>>> outerMap = tsm.loanProcessor(filePath,"12/12/2017");
		//System.out.println(outerMap.get(1));
		//System.out.println(outerMap.get(2));
		/*
		 * Run the following code snippet to validate your code structure before
		 * uploading the code. Do not edit this code.
		 */
		
		
		
	}

	/**
	 * @param filePath
	 * @param sanctionDate
	 * @return Map<Integer, Map<String, List<PolicyHolderVO>>>
	 * @throws TrustLoanException
	 * @throws IOException 
	 */
	public Map<Integer, Map<String, List<PolicyHolderVO>>> loanProcessor(String filePath, String sanctionDate)
			throws TrustLoanException {

		// TODO Associate to type their code here
		// TODO Associate to modify the return statement according to the
		// requirement

		BufferedReader br = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Map<Integer, Map<String, List<PolicyHolderVO>>> outerMap = new HashMap<Integer, Map<String, List<PolicyHolderVO>>>();

		try {

			Map<String, List<PolicyHolderVO>> innerFirstMap = new HashMap<String, List<PolicyHolderVO>>();
			Map<String, List<PolicyHolderVO>> innerSecondMap = new HashMap<String, List<PolicyHolderVO>>();
			List<PolicyHolderVO> elgHolderVOs = new ArrayList<PolicyHolderVO>();
			List<PolicyHolderVO> nelgHolderVOs = new ArrayList<PolicyHolderVO>();
			List<String> policyNumberList = new ArrayList<String>();
			List<PolicyHolderVO> duplicateList = new ArrayList<PolicyHolderVO>();
			List<PolicyHolderVO> invalidList = new ArrayList<PolicyHolderVO>();

			 br = new BufferedReader(new FileReader(filePath));
			String currentLine = null;

			while ((currentLine = br.readLine()) != null) {
				
				String[] tokens = currentLine.split(";");

				//System.out.println(currentLine);

				if (!validateData(tokens)) {
					throw new TrustLoanException("Data validation error.");

				} else {

					//System.out.println("validated successfully");
					
					Date sactionDate = formatter.parse(sanctionDate);
					float sumAssurred = Float.parseFloat(tokens[0].substring(9, tokens[0].length()));
					
					PolicyHolderVO policyHolderVO = new PolicyHolderVO();

					policyHolderVO.setPolicyCode(tokens[0]);
					policyHolderVO.setPan(tokens[1]);
					policyHolderVO.setPolicyStartDate(formatter.parse(tokens[2]));
					policyHolderVO.setPeriod(Integer.parseInt(tokens[3]));
					policyHolderVO.setAccumulatedPremiumAmount(Float.parseFloat(tokens[4]));
					policyHolderVO.setRequestedLoanAmount(Float.parseFloat(tokens[5]));

					Calendar cal = Calendar.getInstance();
					cal.setTime(policyHolderVO.getPolicyStartDate());
					cal.add(Calendar.MONTH, policyHolderVO.getPeriod());
					policyHolderVO.setPolicyEndDate(cal.getTime());

					if (tokens[0].startsWith("NRM")) {
						if (policyHolderVO.getRequestedLoanAmount() > (0.4 * policyHolderVO.getAccumulatedPremiumAmount())) {

							policyHolderVO.setNetPremiumAmount(policyHolderVO.getAccumulatedPremiumAmount());
							nelgHolderVOs.add(policyHolderVO);

						} else if (policyHolderVO.getRequestedLoanAmount() < (0.4 * policyHolderVO.getAccumulatedPremiumAmount())) {

							policyHolderVO.setNetPremiumAmount(calculateNetPremiumAmount(sumAssurred, policyHolderVO, sactionDate));
							elgHolderVOs.add(policyHolderVO);
						
						}
					}

					if (tokens[0].startsWith("FST")) {
						if (policyHolderVO.getRequestedLoanAmount() < (0.6 * policyHolderVO.getAccumulatedPremiumAmount())) {
							
							policyHolderVO.setNetPremiumAmount(calculateNetPremiumAmount(sumAssurred, policyHolderVO, sactionDate));
							elgHolderVOs.add(policyHolderVO);
						
						} else if ((policyHolderVO.getRequestedLoanAmount() > (0.6 * policyHolderVO.getAccumulatedPremiumAmount()))
								&& (policyHolderVO.getRequestedLoanAmount() < (0.7 * sumAssurred))) {
							
							policyHolderVO.setNetPremiumAmount(calculateNetPremiumAmount(sumAssurred, policyHolderVO, sactionDate));
							elgHolderVOs.add(policyHolderVO);
						
						} else if ((policyHolderVO.getRequestedLoanAmount() > (0.6 * policyHolderVO.getAccumulatedPremiumAmount()))
								&& (policyHolderVO.getRequestedLoanAmount() > (0.7 * sumAssurred))) {
							
							policyHolderVO.setNetPremiumAmount(policyHolderVO.getAccumulatedPremiumAmount());
							nelgHolderVOs.add(policyHolderVO);
						
						}
					}
					
					if (policyNumberList.isEmpty()) {
						policyNumberList.add(tokens[0].substring(4, 8));
					} else {
						for (String polNum : policyNumberList) {
							if (polNum.equals(tokens[0].substring(4, 8))) {
								duplicateList.add(policyHolderVO);
							}
						}
						policyNumberList.add(tokens[0].substring(4, 8));
					}

					if (Float.parseFloat(tokens[5]) > sumAssurred) {
						invalidList.add(policyHolderVO);
					}
				}

			}

			//System.out.println(elgHolderVOs);
			//System.out.println(nelgHolderVOs);
			
			innerFirstMap.put("ELG", elgHolderVOs);
			innerFirstMap.put("NELG", nelgHolderVOs);
			innerSecondMap.put("DUP", duplicateList);
			innerSecondMap.put("INV", invalidList);
			outerMap.put(new Integer(1), innerFirstMap);
			outerMap.put(new Integer(2), innerSecondMap);

		} catch (FileNotFoundException e) {
			throw new TrustLoanException("File not found error" + e.getMessage());
		} catch (IOException e) {
			throw new TrustLoanException("File read error" + e.getMessage());
		} catch (ParseException pe) {
			throw new TrustLoanException("Date format error" + pe.getMessage());
		} finally {
			
				if (br != null)
					try {
						br.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						throw new TrustLoanException("Buffered Reader close error" + e.getMessage());
					}
		}

		return outerMap; // TODO Change this return value

	}
	

	
	private static boolean validateData(String[] str) {

		if (str.length != 6)
			return false;

		for (int i = 0; i < str.length; i++) {
			if (!checkAllFields(str[i])) {
				//System.out.println("1");
				return false;
			}
		}

		String policyType = str[0].substring(0, 3);
		if (!policyType.equals("FST") && (!policyType.equals("NRM"))) {
			//System.out.println("2");
			return false;
		}

		String policyNum = str[0].substring(4, 8);

		for (int i = 0; i < policyNum.length(); i++) {
			if (policyNum.charAt(i) == 0) {
				//System.out.println("2.1");
				return false;
			}
			Character ch = policyNum.charAt(i);
			if (!Character.isDigit(ch)) {
				//System.out.println("2.2");
				return false;
			}
		}

		String sumAssured = str[0].substring(9, str[0].length());
		for (int i = 0; i < sumAssured.length(); i++) {
			Character ch = sumAssured.charAt(i);
			if (!Character.isDigit(ch)) {
				//System.out.println("3");
				return false;
			}
		}

		if (!str[1].startsWith("FR")) {
			//System.out.println("4");
			return false;
		}

		String panNumber = str[1].substring(2, 5);
		for (int i = 0; i < panNumber.length(); i++) {
			Character ch = panNumber.charAt(i);
			if (!Character.isDigit(ch)) {
				//System.out.println("5");
				return false;
			}
		}

		if (!isValidDate(str[2])) {
			//System.out.println("6");
			return false;
		}

		if ((Integer.parseInt(sumAssured)) < (Integer.parseInt(str[4]))) {
			//System.out.println("7");
			return false;
		}

		return true;
	}
	
	private static boolean checkAllFields(String fields) {
		if (fields != null && fields.isEmpty())
			return false;
		else
			return true;
	}
	
	private static boolean isValidDate(String strDate) { 
		try{
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(strDate);
		}catch(ParseException pe){
			return false;
		}
		return true;
	}	
	
	private static float calculateNetPremiumAmount(float sumAssured,
			PolicyHolderVO policyHolderVO, Date sanctionDate) {
		float netPremiumAmount = 0.0f;
		float calculatedPremiumAmount = (sumAssured / policyHolderVO
				.getPeriod());
		int loanPeriod = calculateLoanPeriod(policyHolderVO.getPolicyEndDate(),
				sanctionDate);
		float interest = (float) ((policyHolderVO.getRequestedLoanAmount() * 1.2 * loanPeriod)/100);
		float incPremium = ((policyHolderVO.getRequestedLoanAmount() + interest)/loanPeriod);
		netPremiumAmount = (calculatedPremiumAmount + incPremium );
		return netPremiumAmount;

	}
	
	private static int calculateLoanPeriod(Date policyEndDate, Date sanctionDate) {
		int days = (int) ((policyEndDate.getTime()) - (sanctionDate.getTime())
				/ (1000 * 24 * 60 * 60));
		return (days / 30);
	}
	
}