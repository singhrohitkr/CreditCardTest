

class TrustLoanException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TrustLoanException(Throwable throwable) {
		super(throwable);
	}

	public TrustLoanException(String message) {
		super(message);

	}

	public TrustLoanException(String message, Throwable throwable) {
		super(message, throwable);
	}

}