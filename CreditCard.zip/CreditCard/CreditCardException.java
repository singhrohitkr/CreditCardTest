

class CreditCardException extends Exception {

	// Parameterless Constructor
	public CreditCardException() {
	}

	// Constructor that accepts a message
	public CreditCardException(String message) {
		super(message);
	}

	// Constructor that accepts a message
	public CreditCardException(String message, Exception e) {
		super(message, e);
	}

}