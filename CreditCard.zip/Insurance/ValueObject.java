import java.util.Date;

class ValueObject {
	private String PolicyNo;
	private String PolicyHolderName;
	private Double PremiumAmt;
	private Date PremiumDueDate;
	private Date PremiumPaidDate;
	private Double fine;

	public String getPolicyNo() {
		return PolicyNo;
	}

	public void setPolicyNo(String policyNo) {
		PolicyNo = policyNo;
	}

	public String getPolicyHolderName() {
		return PolicyHolderName;
	}

	public void setPolicyHolderName(String policyHolderName) {
		PolicyHolderName = policyHolderName;
	}

	public Double getPremiumAmt() {
		return PremiumAmt;
	}

	public void setPremiumAmt(Double premiumAmt) {
		PremiumAmt = premiumAmt;
	}

	public Date getPremiumDueDate() {
		return PremiumDueDate;
	}

	public void setPremiumDueDate(Date premiumDueDate) {
		PremiumDueDate = premiumDueDate;
	}

	public Date getPremiumPaidDate() {
		return PremiumPaidDate;
	}

	public void setPremiumPaidDate(Date premiumPaidDate) {
		PremiumPaidDate = premiumPaidDate;
	}

	public Double getFine() {
		return fine;
	}

	public void setFine(Double fine) {
		this.fine = fine;
	}

}