package com.practice.hospitamgmt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HospitalServiceManager {

	/**
	 * @param args
	 * @throws HospitalServiceException 
	 */
	
	public static Map fetchDetailsOfHospital(String filePath) throws HospitalServiceException{
		
		
		HashMap finalHospitalDetailsMap=new HashMap();
		
		
		HashMap<String, List<HospitalPatientDetailsVO>> admissionDateMap=new HashMap<String, List<HospitalPatientDetailsVO>>();
		HashMap<String, Integer> patientPhysicianMap=new HashMap<String, Integer>();
		
		List<HospitalPatientDetailsVO> entList=new ArrayList<HospitalPatientDetailsVO>();
		List<HospitalPatientDetailsVO> genList=new ArrayList<HospitalPatientDetailsVO>();
		List<HospitalPatientDetailsVO> neuList=new ArrayList<HospitalPatientDetailsVO>();
		
		
		String physicianCategory="";
		String mrnNumber="";
	    String patientName="";
		Date admissionDate=null;
		Date dischargeDate=null;
		double billAmount=0;
		double feesAmount=0;
		String gender="";

		String dateOfAdmission="";
		String dateOfDischarge="";
		String category="";
		String physicianNumber = "";
		
		String sCurrentLine="";
		
		File file=new File(filePath);
		
		//if(file.exists()){
		BufferedReader br=null;
		FileReader fr=null;
		
		HospitalServiceManager hospitalServiceManager=new HospitalServiceManager();
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		sdf.setLenient(false);
		try {
			fr=new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new HospitalServiceException("File doesnot exists in the system!!!");
		}
		
		
		br=new BufferedReader(fr);
		
		try {
			while((sCurrentLine=br.readLine())!=null){
				
			String values[] =sCurrentLine.split("\\|");	
				
			/*boolean validationResult=hospitalServiceManager.validateData(values);
				
			if(validationResult){
				
				throw new HospitalServiceException("Validation has failed!!");
			}*/	
			
			
			if(values.length != 6){
				throw new HospitalServiceException("All fields are mandatory.");
			}
			
			
//			else{
				
				patientName=values[0];
				mrnNumber=values[1];
				gender=values[2];
				physicianCategory=values[3];
				dateOfAdmission=values[4];
				dateOfDischarge=values[5];
				
				for(int i=0; i<patientName.length(); i++){
					if(!(Character.isLetter(patientName.charAt(i)) || Character.isSpace(patientName.charAt(i)))){
						throw new HospitalServiceException("Patient Name should contain only alphabet and white space.");
					}
				}
				
				
				try {
					admissionDate=sdf.parse(dateOfAdmission);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					throw new HospitalServiceException("Admission date should be in dd/MM/yyyy format only!!!");
				}
				
				try {
					dischargeDate=sdf.parse(dateOfDischarge);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					throw new HospitalServiceException("Discharge date should be in dd/MM/yyyy format only!!!");
				}
				
				if(admissionDate.after(dischargeDate)){
					throw new HospitalServiceException("Admission date should not be greater than Discharge date.");
				}
				if(!(mrnNumber.startsWith("IN") || mrnNumber.startsWith("OUT"))){
					throw new HospitalServiceException("MRN should start with IN or OUT.");
				}
				if(!Character.isDigit(mrnNumber.charAt(mrnNumber.length()-1))){
					throw new HospitalServiceException("MRN should end with an integer.");
				}
				
				String physicianValues[]=physicianCategory.split("-");
				physicianNumber = physicianValues[0];
				category=physicianValues[1];
				
				
				for(int j = 0; j < physicianNumber.length(); j++){
					if(!Character.isDigit(physicianNumber.charAt(j))){
						throw new HospitalServiceException("Physician Id should be a combination of 4 digit number.");
					}
				}
				
				if(physicianNumber.length() != 4){
					throw new HospitalServiceException("Physician Id should be a combination of 4 digit number.");
				}
				
				//System.out.println("physician category is::"+category);
				
//				billAmount=hospitalServiceManager.calculateFeesAmount(admissionDate,dischargeDate,category);
				int noOfDays=(int) ((dischargeDate.getTime()-admissionDate.getTime())/(1000*60*60*24));
				if(category.equals("GEN")){
					billAmount = noOfDays * 1250;
				}
				if(category.equals("ENT")){
					billAmount = noOfDays * 1500;
				}
				if(category.equals("NEU")){
					billAmount = noOfDays * 1750;
				}
				
				//put values for 1st map
				HospitalPatientDetailsVO hospitalPatientDetailsVO=new HospitalPatientDetailsVO();
				
				hospitalPatientDetailsVO.setPatientName(patientName);
				hospitalPatientDetailsVO.setMrnNumber(mrnNumber);
				hospitalPatientDetailsVO.setGender(gender);
				hospitalPatientDetailsVO.setPhysicianCategory(category);
				hospitalPatientDetailsVO.setAdmissionDate(admissionDate);
				hospitalPatientDetailsVO.setDischargeDate(dischargeDate);
				hospitalPatientDetailsVO.setBillAmount(billAmount);				
				
				
				
				List<HospitalPatientDetailsVO> existingHospitalPatientDetailsList=admissionDateMap.get(dateOfAdmission);
				
				if(existingHospitalPatientDetailsList==null){
					
					List<HospitalPatientDetailsVO> hospitalPatientAdmissionDateList=new ArrayList<HospitalPatientDetailsVO>();
					
					hospitalPatientAdmissionDateList.add(hospitalPatientDetailsVO);
					admissionDateMap.put(dateOfAdmission, hospitalPatientAdmissionDateList);
				}
				
				else{
					boolean flag = false;
					for(HospitalPatientDetailsVO selectedHospitalPatientDetailsVO:existingHospitalPatientDetailsList){
											
						if(selectedHospitalPatientDetailsVO.getMrnNumber().equals(mrnNumber)){
							flag=true;
						}
						
					}
					if(!flag){
						existingHospitalPatientDetailsList.add(hospitalPatientDetailsVO);
						
						admissionDateMap.put(dateOfAdmission, existingHospitalPatientDetailsList);
					}
				}
				
				
				//compute values for second map
				
				if("ENT".equals(category)){
					
					boolean flag=false;
					HospitalPatientDetailsVO entDetailsVO=new HospitalPatientDetailsVO();
					
					entDetailsVO.setAdmissionDate(admissionDate);
					entDetailsVO.setDischargeDate(dischargeDate);
					entDetailsVO.setGender(gender);
					entDetailsVO.setMrnNumber(mrnNumber);
					entDetailsVO.setPatientName(patientName);
					entDetailsVO.setPhysicianCategory(category);
					
					//for(HospitalPatientDetailsVO selectedHospitalPatientDetailsVO:entList){
						
					for(int i=0;i<entList.size();i++){
						HospitalPatientDetailsVO selectedHospitalPatientDetailsVO =entList.get(i);
						
						if(selectedHospitalPatientDetailsVO.getMrnNumber().equals(mrnNumber)){
							flag=true;
						}
						
					}
					
					if(!flag){
						entList.add(entDetailsVO);
					}
				}
				
				
				if("NEU".equals(category)){
					
					boolean flag=false;
					HospitalPatientDetailsVO neuDetailsVO=new HospitalPatientDetailsVO();
					
					neuDetailsVO.setAdmissionDate(admissionDate);
					neuDetailsVO.setDischargeDate(dischargeDate);
					neuDetailsVO.setGender(gender);
					neuDetailsVO.setMrnNumber(mrnNumber);
					neuDetailsVO.setPatientName(patientName);
					neuDetailsVO.setPhysicianCategory(category);
					
					//for(HospitalPatientDetailsVO selectedHospitalPatientDetailsVO:NeuList){
					for(int i=0;i<neuList.size();i++){
						HospitalPatientDetailsVO selectedHospitalPatientDetailsVO =neuList.get(i);
						
						if(selectedHospitalPatientDetailsVO.getMrnNumber().equals(mrnNumber)){
							flag=true;
						}
						
					}
					
					if(!flag){
						neuList.add(neuDetailsVO);
					}
				}
				
				if("GEN".equals(category)){
					
					boolean flag=false;
					HospitalPatientDetailsVO genDetailsVO=new HospitalPatientDetailsVO();
					
					genDetailsVO.setAdmissionDate(admissionDate);
					genDetailsVO.setDischargeDate(dischargeDate);
					genDetailsVO.setGender(gender);
					genDetailsVO.setMrnNumber(mrnNumber);
					genDetailsVO.setPatientName(patientName);
					genDetailsVO.setPhysicianCategory(category);
					
					for(HospitalPatientDetailsVO selectedHospitalPatientDetailsVO:genList){
						
						if(selectedHospitalPatientDetailsVO.getMrnNumber().equals(mrnNumber)){
							flag=true;
						}
						
					}
					
					if(!flag){
						genList.add(genDetailsVO);
					}
				}
				patientPhysicianMap.put("GEN", genList.size());
				patientPhysicianMap.put("NEU", neuList.size());
				patientPhysicianMap.put("ENT", entList.size());				
				
//			}
			
			
			}
			
			
			System.out.println("size of entlist::"+entList.size());
			System.out.println("size of NeuList::"+neuList.size());
			System.out.println("size of GenList::"+genList.size());
			
			
			for(String key:admissionDateMap.keySet()){
				System.out.println("-------------");
				System.out.println("looping through admission date map");
				System.out.println("key::"+key+"value of patientname::"+admissionDateMap.get(key).size());
				
			}
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new HospitalServiceException("i/O exception has occured!!!");
			
			
		}
		
		
		
		
		finalHospitalDetailsMap.put(1, admissionDateMap);
		finalHospitalDetailsMap.put(2, patientPhysicianMap);
	
	
	//}
		return finalHospitalDetailsMap;
	}	
	
	
	
	
	/*private boolean validateData(String[] str){
		
		boolean result=false;
		
		return result;
	}*/
	
	
	/*private float calculateFeesAmount(Date date1, Date date2,String category){
		float billamount=0.00f;
		
		// Write your code here
		int gapOfDays=(int) ((date2.getTime()-date1.getTime())/(1000*60*60*24));
		
		billamount=gapOfDays*1750;
		
		
		return billamount;
		
	
		
		
	}
	*/
	
	
	
	public static void main(String[] args) throws HospitalServiceException {
		HospitalServiceManager hospitalServiceManager=new HospitalServiceManager();
		String filePath="D:\\Workspace_practice_axis2-jdk1.4-Next\\RDPExamPractice\\src\\com\\practice\\hospitamgmt\\HospitalPatientDetails.dat";
		hospitalServiceManager.fetchDetailsOfHospital(filePath);
		

	}

}
